#include <fstream>
#include <iostream>
#include <memory>
#include <random>
#include <vector>

#include "../include/staticmsgs.h"

#include "../include/Tick.h"
#include "../include/TickManager.h"

#include "../include/RandomTickManager.h"
#include "../include/YahooFinanceFileTickManager.h"

#include "../include/RandomBuySellStrategy.h"
#include "../include/SmaStrategy.h"
#include "../include/Strategy.h"

#include "../include/PaperTradeManager.h"
#include "../include/Trade.h"
#include "../include/TradeManager.h"

#include "../include/VirtualBank.h"

#include "../include/CSVWriter.h"

using namespace std;

int main(int argc, char **argv) {
  /* Everything related to command-line options */
  string input_file{"sample_inputs/MARUTI.NS.csv"};
  string output_file{"output.csv"}; // path to input file
                                    // path to output file
  /* End everything related to command-line options */

  /* Initialise tick manager */
  unique_ptr<TickManager> tick_manager;
  // tick_manager = make_unique<RandomTickManager>();
  tick_manager = make_unique<YahooFinanceFileTickManager>(input_file);

  /* Initialise strategy */
  unique_ptr<Strategy> strategy;
  // strategy = make_unique<RandomBuySellStrategy>();
  strategy = make_unique<SmaStrategy>();

  /* Initialise a virtual bank */
  REAL bank_balance = 100000;
  auto virtual_bank = make_shared<VirtualBank>(bank_balance);

  /* Initialise trade manager */
  unique_ptr<TradeManager> trade_manager;
  trade_manager = make_unique<PaperTradeManager>(virtual_bank);

  Tick last_traded_tick;

  /* Start the core event-loop */
  while (tick_manager->hasNextTick()) {
    last_traded_tick = tick_manager->getNextTick();

    Trade tr = strategy->processTick(last_traded_tick);
    trade_manager->performTrade(tr);
  }

  trade_manager->squareOff(last_traded_tick);
  trade_manager->dumpTrades();

  string final_bank_balance = to_string(virtual_bank->getBankBalance());
  string profit_or_loss =
      to_string(virtual_bank->getBankBalance() - bank_balance);

  cout << "Total Bank Balance: " << final_bank_balance << endl;
  cout << "Profit or loss: " << profit_or_loss << endl << endl;

  // q1.1
  // Test data for Tick
  Tick sampleTick = {6054.399902, 5857.500000, 5882.350098, 6055.700195,
                     5801.429688, 1097857,     20190718};

  // Print single Tick
  cout << "Single Tick Output:" << endl;
  cout << sampleTick << endl;

  // Simulate multiple ticks
  vector<Tick> tickVector = {{6054.399902, 5857.500000, 5882.350098,
                              6055.700195, 5801.429688, 1097857, 20190718},
                             {6060.500000, 5860.100000, 5890.600000,
                              6062.000000, 5810.500000, 1081234, 20190719},
                             {6070.000000, 5870.000000, 5900.000000,
                              6075.000000, 5820.000000, 1100000, 20190720}};

  cout << "\nMultiple Tick Outputs:" << endl;
  for (const auto &tick : tickVector) {
    cout << tick << endl;
  }

  // Test data for Trade
  Trade sampleTrade(Trade::Move::PASS, 10, sampleTick);

  // Print single Trade
  cout << "Single Trade Output:" << endl;
  cout << sampleTrade << endl;

  // Simulate multiple trades
  vector<Trade> tradeVector = {{Trade::Move::BUY, 5, sampleTick},
                               {Trade::Move::SELL, 15, sampleTick},
                               {Trade::Move::PASS, 10, sampleTick}};

  cout << "\nMultiple Trade Outputs:" << endl;
  for (const auto &trade : tradeVector) {
    cout << trade << endl << endl;
  }

  CSVWriterTest(); // q1.2

  return 0;
}
