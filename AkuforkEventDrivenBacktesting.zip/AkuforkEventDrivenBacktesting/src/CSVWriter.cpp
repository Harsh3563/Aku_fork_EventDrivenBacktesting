#include "../include/CSVWriter.h"
#include "../include/Tick.h"
#include "../include/Trade.h"
#include <iostream>
#include <vector>

using namespace std;

void CSVWriterTest() {
  // Example trades and ticks for backtesting
  Tick sampleTick1 = {6054.399902, 5857.500000, 5882.350098, 6055.700195,
                      5801.429688, 1097857,     20190718};
  Tick sampleTick2 = {6060.500000, 5860.000000, 5890.200000, 6070.100098,
                      5820.100000, 1098000,     20190719};

  Trade trade1(Trade::Move::BUY, 10, sampleTick1);
  Trade trade2(Trade::Move::SELL, 5, sampleTick2);
  Trade trade3(Trade::Move::PASS, 0, sampleTick1);

  // Store trades in a vector
  vector<Trade> tradeHistory = {trade1, trade2, trade3};

  // Output CSV file name
  string output_file = "output.csv";

  // Create CSVWriter instance
  try {
    CSVWriter writer(output_file);

    // Write header for the trade CSV file
    vector<string> header = {"Action",    "Price", "Quantity", "Date",
                             "Open",      "Low",   "Close",    "High",
                             "Adj Close", "Volume"};
    writer.writeHeader(header);

    // Write all trades to the CSV file
    for (const auto &trade : tradeHistory) {
      writer.write(trade);
    }

    cout << "Trades written successfully to " << output_file << endl;

  } catch (const exception &e) {
    cerr << "Error: " << e.what() << endl;
  }
}
