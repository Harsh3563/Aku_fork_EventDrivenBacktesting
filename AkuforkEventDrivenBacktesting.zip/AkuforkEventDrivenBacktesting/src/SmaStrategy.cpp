#include "../include/SmaStrategy.h"
#include "../include/Trade.h"
#include <iostream>

using namespace std;

using Move = Trade::Move;

Trade SmaStrategy::processTick(Tick tick) {
  int quantity = 10;
  int smaDayRange = 5;
  // int differenceTolerance = 100;
  Trade::Move mv;

  this->tickCount += 1;
  this->totalClosingPrice += tick.close;

  // following block will ensure that if we are making good profit, exit
  // position.
  if (this->lastBoughtPrice != 0 && (tick.close - this->lastBoughtPrice) > 10) {
    mv = Move::SELL;
    if (DEBUG_FLAG) {
      cout << "SmaStrategy: Safe SELL SIGNAL generated" << endl;
    }
    /* FIX: 1.
    Problem Description: The code might fail to trigger multiple buy signals
    as isPosition is set to true, and it doesn't check for further trades
    after the first buy. We need to reset the position after selling the
    holding to allow for further buys.

    Code to be added: this->isPosition = false;
    */
    this->isPosition = false;
    /* FIX: 1. END */
    return Trade(mv, quantity, tick);
  }

  if (this->tickCount >= smaDayRange) {
    REAL ma = this->totalClosingPrice / smaDayRange;
    this->tickCount = 0;
    this->totalClosingPrice = 0;

    if (tick.close > ma
        /* FIX: 2.
        Problem Description: The current implementation does not properly handle
        the scenario where the strategy should hold up to 10 shares max, which
        might be one of the reasons the strategy executes only 4 trades instead
        of more (until the position limit is reached). We should trigger
        additional Buy signals only if no position is held, to ensure
        that we don't exceed the holding upper limit of 10 shares.

        Replacement Code: if (tick.close > ma && !this->isPosition)
        */
        && !this->isPosition
        /* FIX: 2. END */) {
      this->isPosition = true;
      mv = Move::BUY;
      this->lastBoughtPrice = tick.close;
      if (DEBUG_FLAG) {
        cout << "SmaStrategy: BUY SIGNAL generated" << endl;
      }
    } else {
      mv = Move::PASS;
      if (DEBUG_FLAG) {
        cout << "SmaStrategy: PASS SIGNAL generated" << endl;
      }
    }
  } else {
    mv = Move::PASS;
    if (DEBUG_FLAG) {
      cout << "SmaStrategy: PASS SIGNAL generated" << endl;
    }
  }

  return Trade(mv, quantity, tick);
}
