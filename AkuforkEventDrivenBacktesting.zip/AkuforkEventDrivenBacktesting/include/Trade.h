#pragma once

#include "Tick.h"
#include <iostream>
#include <string>

using namespace std;

class Trade {
public:
  enum class Move { BUY, SELL, PASS };
  Move mv;
  int quantity;
  Tick tick;

  Trade(Trade::Move mv, int quantity, Tick tick)
      : mv(mv), quantity(quantity), tick(tick) {}

  void dump() {
    cout << "Dumping a trade sequence" << endl;
    const string trade_move = moveToString();
    cout << "TradeMove - " << trade_move << endl;
    cout << "Trade quantity - " << this->quantity << endl;
    cout << "Tick Info -- " << endl;
    this->tick.dump();
    cout << endl;
  }

  // Helper function to convert move enum to string
  string moveToString() const {
    switch (mv) {
    case Move::BUY:
      return "BUY";
    case Move::SELL:
      return "SELL";
    case Move::PASS:
      return "PASS";
    default:
      return "UNKNOWN";
    }
  }

  // Overload operator<< for Trade
  friend ostream &operator<<(ostream &os, const Trade &trade) {
    os << trade.moveToString() << "," // Trade action (BUY, SELL, PASS)
       << fixed << setprecision(2) << trade.tick.close
       << ","                   // Trade price (use the tick's close price)
       << trade.quantity << "," // Share quantity
       << trade.tick; // Append the tick in CSV format using the Tick operator<<
    return os;
  }
};
