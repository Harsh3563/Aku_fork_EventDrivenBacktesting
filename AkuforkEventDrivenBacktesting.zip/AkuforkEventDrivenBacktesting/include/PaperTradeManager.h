#pragma once

#include "TradeManager.h"
#include "VirtualBank.h"
#include <memory>

using namespace std;

class PaperTradeManager : public TradeManager {
public:
  shared_ptr<VirtualBank> virtual_bank;
  int holdQuantity;

  PaperTradeManager(shared_ptr<VirtualBank> virtual_bank);
  virtual ~PaperTradeManager() {
    // Perform any cleanup logic here if needed
    // Currently empty as no specific cleanup is required
  }
  void performBuy(Trade trade);
  void performSell(Trade trade);
  bool canBuy(Trade trade);
  bool canSell(Trade trade);
  bool squareOff(Tick last_tick);
};
