#pragma once

#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;

class CSVWriter {
private:
  ofstream file;

public:
  // Constructor: Opens the file
  explicit CSVWriter(const string &filename) {
    file.open(filename, ios::out);
    if (!file.is_open()) {
      throw runtime_error("Could not open file: " + filename);
    }
  }

  // Destructor: Closes the file
  ~CSVWriter() {
    if (file.is_open()) {
      file.close();
    }
  }

  // Method to write a header to the CSV file
  void writeHeader(const vector<string> &header) {
    for (size_t i = 0; i < header.size(); ++i) {
      file << header[i];
      if (i < header.size() - 1)
        file << ",";
    }
    file << "\n";
  }

  // Template write method to write any object with overloaded operator<<
  template <typename T> void write(const T &data) {
    if (file.is_open()) {
      file << data << "\n";
    } else {
      throw runtime_error("File not open for writing.");
    }
  }
};

void CSVWriterTest();
