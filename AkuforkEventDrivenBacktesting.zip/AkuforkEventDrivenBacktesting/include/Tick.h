#pragma once

#include "common.h"
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

struct Tick {
  REAL open;
  REAL low;
  REAL close;
  REAL high;
  REAL adjust_close;
  INT volume;
  INT time; // Representing date/time as YYYYMMDD (integer format)

  void dump();

  // Overload operator<< for Tick
  friend ostream &operator<<(ostream &os, const Tick &tick) {
    os << tick.time << ","         // YYYYMMDD already formatted as integer
       << fixed << setprecision(2) // Force 2 dp precision
       << tick.open << "," << tick.low << "," << tick.close << "," << tick.high
       << "," << tick.adjust_close << "," << tick.volume;
    return os;
  }
};
