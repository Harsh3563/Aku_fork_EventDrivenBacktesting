#pragma once

#include "Tick.h"
#include <iostream>

class TickManager {
public:
  virtual Tick getNextTick() = 0;
  virtual bool hasNextTick() = 0;
  virtual ~TickManager() {
    // Perform any cleanup logic here if needed
    // Currently empty as no specific cleanup is required
  }
};
