#pragma once

#include "TradeManager.h"

class Strategy {
public:
  virtual Trade processTick(Tick t) = 0;
  virtual ~Strategy() {
    // Perform any cleanup logic here if needed
    // Currently empty as no specific cleanup is required
  }
};
