#pragma once

using REAL = long double;
using INT = long int;